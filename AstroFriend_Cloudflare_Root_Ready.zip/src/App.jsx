import { useEffect, useMemo, useRef, useState } from "react";
import { BrowserRouter, Link, NavLink, Navigate, Route, Routes, useLocation, useNavigate, useSearchParams, useParams } from "react-router-dom";
import { supabase } from "./supabase";
import { experts, services, getPrice } from "./data/catalog";

function AppShell() {
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [replyNotice, setReplyNotice] = useState(null);
  const location = useLocation();

  useEffect(() => {
    let alive = true;
    supabase.auth.getSession().then(({ data, error }) => {
      if (error) console.error("Session check:", error.message);
      if (!alive) return;
      const sessionUser = data?.session?.user ?? null;
      setUser(sessionUser?.email_confirmed_at ? sessionUser : null);
      setAuthReady(true);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      const sessionUser = session?.user ?? null;
      // Unconfirmed sessions must never unlock customer-only pages.
      setUser(sessionUser?.email_confirmed_at ? sessionUser : null);
    });
    return () => { alive = false; listener?.subscription?.unsubscribe(); };
  }, []);

  const lastAdminMessage = useRef(null);
  useEffect(() => {
    if (!user) { lastAdminMessage.current = null; return; }
    let alive = true;
    const checkReplies = async () => {
      const { data: chats } = await supabase.from("af_chat_sessions").select("id").eq("customer_id", user.id);
      const ids = (chats || []).map(x => x.id);
      if (!ids.length || !alive) return;
      const { data: latest } = await supabase.from("af_chat_messages").select("id,message,created_at,session_id").eq("sender", "admin").in("session_id", ids).order("created_at", { ascending: false }).limit(1).maybeSingle();
      if (!alive) return;
      if (!latest) { if (lastAdminMessage.current === null) lastAdminMessage.current = "__none__"; return; }
      if (lastAdminMessage.current && latest.id !== lastAdminMessage.current && lastAdminMessage.current !== "__none__") {
        setReplyNotice({ id: latest.id, sessionId: latest.session_id, message: latest.message });
        if ("Notification" in window && Notification.permission === "granted") new Notification("AstroFriend – Expert Reply", { body: latest.message || "Aapke expert ka naya reply aaya hai.", tag: latest.id });
      }
      lastAdminMessage.current = latest.id;
    };
    checkReplies();
    const timer = setInterval(checkReplies, 5000);
    return () => { alive = false; clearInterval(timer); };
  }, [user?.id]);
  useEffect(() => { setMobileMenu(false); window.scrollTo(0, 0); }, [location.pathname]);

  const logout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) window.alert(error.message);
    else setUser(null);
  };

  if (!authReady) return <div className="loading-screen">✦ AstroFriend</div>;
  return <div className="app-shell">
    <header className="navbar">
      <Link className="brand" to="/"><span className="brand-icon">✦</span><span>Astro<span>Friend</span></span></Link>
      <nav className="nav-links">
        <NavLink to="/">Home</NavLink><NavLink to="/services">Services</NavLink>
        {user && <><NavLink to="/account">My Account</NavLink><NavLink to="/wallet">Wallet</NavLink><NavLink to="/astro-ai">Consultation</NavLink></>}
      </nav>
      <div className="nav-actions">
        {user ? <span className="user-chip">{user.user_metadata?.full_name || user.email}</span> : <><Link className="nav-button ghost-button" to="/login">Login</Link><Link className="nav-button" to="/signup">Sign Up</Link></>}
      </div>
    </header>
    {replyNotice && <div className="notice-inline reply-toast"><span>Expert ka naya reply: {replyNotice.message}</span> <Link to={`/chat/${replyNotice.sessionId}`}>Open chat</Link> <button type="button" onClick={()=>setReplyNotice(null)} aria-label="Dismiss">×</button></div>}
    <main><Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/services" element={<ServicesPage />} />
      <Route path="/experts" element={<Navigate to="/" replace />} />
      <Route path="/booking" element={<BookingPage user={user} />} />
      <Route path="/login" element={<LoginPage user={user} />} />
      <Route path="/signup" element={<SignupPage />} />
      <Route path="/verify-email" element={<VerifyPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route path="/account" element={<Protected user={user}><AccountPage user={user} onLogout={logout} /></Protected>} />
      <Route path="/wallet" element={<Protected user={user}><WalletPage user={user} /></Protected>} />
      <Route path="/chat" element={<Protected user={user}><ChatPage user={user} /></Protected>} />
      <Route path="/inbox" element={<Protected user={user}><InboxPage user={user} /></Protected>} />
      <Route path="/chat/:sessionId" element={<Protected user={user}><ChatConversationPage user={user} /></Protected>} />
      <Route path="/astro-ai" element={<Protected user={user}><AstroAIPage user={user} /></Protected>} />
      <Route path="/help-us" element={<Protected user={user}><HelpUsPage user={user} /></Protected>} />
      <Route path="/admin" element={<Protected user={user}><AdminPage user={user} /></Protected>} />
      <Route path="*" element={<NotFound />} />
    </Routes></main>
    {user && <nav className="mobile-bottom-nav" aria-label="Mobile navigation">
      <NavLink to="/" end><span>⌂</span><small>Home</small></NavLink>
      <NavLink to="/services"><span>▦</span><small>Services</small></NavLink>
      <NavLink to="/inbox"><span>▤</span><small>Inbox</small></NavLink>
      <NavLink to="/wallet"><span>◉</span><small>Wallet</small></NavLink>
      <NavLink to="/astro-ai"><span>✦</span><small>Consultation</small></NavLink>
      <NavLink to="/account"><span>♙</span><small>Account</small></NavLink>
    </nav>}
  </div>;
}

function SectionHeading({ eyebrow = "ASTROFRIEND", title, text }) { return <div className="section-heading"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{text && <p>{text}</p>}</div>; }
function HomePage() {
  return <>
    <ExpertsPage embedded />
    <section className="section"><SectionHeading title="Our Services" text="Choose the service you need. Final price depends on the selected expert."/><div className="service-grid">{services.map((s,i)=><ServiceCard key={s.name} service={s} icon={["☼","☾","✧","◉","◉","✦","♧"][i]}/>)}</div></section>
  </>;
}
function ServiceCard({ service, icon = "✦" }) { const isChat=service.name.toLowerCase().includes("chat"); return <Link className="service-card service-card-link" to={isChat?"/experts":"/astro-ai"}><span className="service-icon">{icon}</span><h3>{service.name}</h3><p>{isChat?"Choose an expert to start a paid chat.":"Continue to AstroFriend Consultation."}</p><strong className="service-price">{service.senior === 0 ? "FREE" : `₹${service.other} – ₹${service.senior}`}</strong><small className="service-caption">{isChat?"Select an expert":"Open consultation"}</small></Link>; }
function ServicesPage() { return <section className="page-section"><SectionHeading title="Our Services" text="Choose a chat duration or open AstroFriend Consultation."/><div className="service-grid">{services.map((s,i)=><ServiceCard key={s.name} service={s} icon={["◷","◷","☼","☾","✧","✦","♧"][i]}/>)}</div></section>; }

function ExpertsPage({embedded=false} = {}) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");

  const filtered = useMemo(
    () =>
      experts.filter(
        e =>
          e.name.toLowerCase().includes(search.toLowerCase()) &&
          (filter === "All" || e.level === filter)
      ),
    [search, filter]
  );

  return (
    <section className={embedded ? "page-section home-experts" : "page-section"}>
      <SectionHeading
        title="Meet Our Experts"
        text="Browse our 29 listed experts and compare consultation rates."
      />

      <div className="expert-tools">
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search expert name..."
        />
        <span className="result-count">
          {filtered.length} experts
        </span>
      </div>

      <div className="filter-list">
        {["All", "Senior", "Other"].map(f => (
          <button
            key={f}
            className={filter === f ? "filter active" : "filter"}
            onClick={() => setFilter(f)}
          >
            {f === "All"
              ? "All Experts"
              : f === "Senior"
              ? "Senior Experts"
              : "Other Experts"}
          </button>
        ))}
      </div>

      <div className="expert-grid">
        {filtered.map(expert => (
          <article className="expert-card" key={expert.name}>
            <div className="expert-top">
              <div className="avatar">
                <img src={expert.photo} alt={expert.name} />
              </div>
              <span className="status offline">Listed Expert</span>
            </div>

            <div className="expert-info">
              <span className="rating">
                ⭐ {expert.rating} / 5
              </span>

              <h3>{expert.name}</h3>

              <p className="expert-category">
                {expert.level === "Senior"
                  ? "Senior Expert"
                  : "Expert"}
              </p>

              <p className="experience">
                {expert.experience} Years of Experience
              </p>

              <div className="expert-bottom">
                <span className="price">
                  From ₹
                  {Math.min(
                    ...services
                      .filter(s => s.senior > 0)
                      .map(s =>
                        expert.level === "Senior"
                          ? s.senior
                          : s.other
                      )
                  )}
                  <small> / service</small>
                </span>

                <Link
                  className="view-btn"
                  to={`/booking?expert=${encodeURIComponent(expert.name)}`}
                >
                  View & Book
                </Link>
              </div>
            </div>
          </article>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="empty-state">
          No experts found. Try another name.
        </div>
      )}
    </section>
  );
}

function BookingPage({user}) {
  const [params] = useSearchParams(); const navigate=useNavigate();
  const expertName = params.get("expert") || "";
  const [serviceName,setServiceName]=useState("Chat – 5 Minutes");
  const [name,setName]=useState(user?.user_metadata?.full_name||"");
  const [birthDate,setBirthDate]=useState("");
  const [birthPlace,setBirthPlace]=useState("");
  const [birthTime,setBirthTime]=useState("");
  const [partnerName,setPartnerName]=useState("");
  const [partnerBirthDate,setPartnerBirthDate]=useState("");
  const [partnerBirthPlace,setPartnerBirthPlace]=useState("");
  const [partnerBirthTime,setPartnerBirthTime]=useState("");
  const [message,setMessage]=useState("");
  const [notice,setNotice]=useState("");
  const [report,setReport]=useState("");
  const [busy,setBusy]=useState(false);
  const expert=experts.find(e=>e.name===expertName);
  const service=services.find(s=>s.name===serviceName)||services[0];
  const isHumanChat=serviceName.toLowerCase().includes("chat");
  const isMatching=serviceName.toLowerCase().includes("matching");
  const submit=async e=>{
    e.preventDefault();
    if(!user){navigate("/login?next=/");return;}
    if(!expert){setNotice("Expert select nahi hua. Experts page se dobara Book Now karein.");return;}
    if(!birthDate||!birthPlace.trim()||!birthTime){setNotice("Date of Birth, Birth Place aur Birth Time bharna zaroori hai.");return;}
    if(isMatching&&(!partnerBirthDate||!partnerBirthPlace.trim()||!partnerBirthTime)){setNotice("Kundli Matching ke liye doosre vyakti ki Date of Birth, Birth Place aur Birth Time bhi bharein.");return;}
    const price=Number(getPrice(expert,service)||0);
    setBusy(true);setNotice("");setReport("");
    const bookingPayload={
      p_expert_name:expertName,p_service_name:serviceName,p_customer_name:name.trim(),
      p_birth_date:birthDate,p_birth_place:birthPlace.trim(),p_birth_time:birthTime,
      p_message:message.trim()||null,p_consultation_price:price
    };
    if(isHumanChat){
      const perMinute=expert.level==="Senior"?5:4;
      const {data:sessionId,error:chatError}=await supabase.rpc("af_create_chat_request",{p_expert_name:expertName,p_rate_per_minute:perMinute});
      if(chatError){setNotice(chatError.message||"Insufficient Wallet Balance");setBusy(false);return;}
      const {error:saveError}=await supabase.rpc("af_save_chat_booking",{...bookingPayload,p_session_id:sessionId});
      if(saveError){await supabase.rpc("af_end_chat",{p_session_id:sessionId});setNotice(saveError.message||"Booking save nahi hui.");setBusy(false);return;}
      setNotice("Information successfully send ho gayi. Aapki private chat khol rahe hain...");
      setBusy(false);navigate(`/chat/${sessionId}`);return;
    }
    // Fixed-price reports are charged only when the report is successfully generated.
    if(price>0){
      const {data:walletData,error:walletError}=await supabase.from("af_wallets").select("balance").eq("user_id",user.id).maybeSingle();
      if(walletError){setNotice("Error funds: wallet balance check nahi ho paya.");setBusy(false);return;}
      if(Number(walletData?.balance||0)<price){setNotice("Error funds: wallet mein paryapt balance nahi hai.");setBusy(false);return;}
    }
    try{
      const response=await fetch("/api/astro-ai",{method:"POST",headers:{"Content-Type":"application/json", "Authorization":`Bearer ${(await supabase.auth.getSession()).data?.session?.access_token||""}`},body:JSON.stringify({
        service:serviceName,expertName,
        birthDetails:{name:name.trim(),date:birthDate,place:birthPlace.trim(),time:birthTime,
          matchingPartner:isMatching?{name:partnerName.trim(),date:partnerBirthDate,place:partnerBirthPlace.trim(),time:partnerBirthTime}:null},
        messages:[{role:"user",content:`Please prepare my ${serviceName} report using the birth details provided. Additional question or context: ${message.trim()||"Please provide the requested service report."}`}]
      })});
      const data=await response.json();
      if(!response.ok)throw new Error(data.error||"Astrology report service abhi available nahi hai.");
      const {error:saveError}=await supabase.rpc("af_save_paid_booking",{...bookingPayload,p_charge_now:price>0});
      if(saveError)throw new Error(saveError.message||"Booking save ya payment process nahi ho paya.");
      setReport(data.reply||"Report generate nahi ho payi.");
      setNotice(price>0?"Booking submit ho gayi. Report generate hone par consultation charge wallet se deduct ho gaya.":"Booking submit ho gayi aur report taiyar hai.");
    }catch(err){setNotice(err.message||"Report generate nahi ho payi; wallet se paise nahi kate.");}
    finally{setBusy(false);}
  };
  return <section className="page-section narrow-page"><SectionHeading title="Book a Consultation" text="Your selected expert is already chosen. Share your birth details for the selected service."/><form className="form-card chat-request-form" onSubmit={submit}>
    <div className="selected-expert"><span>Selected Expert</span><strong>{expertName||"No expert selected"}</strong></div>
    <label>Select Service<select value={serviceName} onChange={e=>{setServiceName(e.target.value);setReport("");setNotice("");}}>{services.filter(s=>s.name.toLowerCase().includes("chat")).map(s=><option key={s.name}>{s.name}</option>)}</select></label>
    {expert&&<div className="price-preview">Consultation price <strong>{getPrice(expert,service)===0?"FREE":`₹${getPrice(expert,service)}`}</strong></div>}
    <label>Your Name<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Your full name"/></label>
    <div className="birth-details-title">Your Birth Details</div>
    <label>Date of Birth<input required type="date" value={birthDate} onChange={e=>setBirthDate(e.target.value)} max={new Date().toISOString().slice(0,10)}/></label>
    <label>Place of Birth<input required value={birthPlace} onChange={e=>setBirthPlace(e.target.value)} placeholder="City, State, Country"/></label>
    <label>Time of Birth<input required type="time" value={birthTime} onChange={e=>setBirthTime(e.target.value)}/></label>
    {isMatching&&<><div className="birth-details-title">Second Person's Birth Details</div>
      <label>Second Person's Name (optional)<input value={partnerName} onChange={e=>setPartnerName(e.target.value)} placeholder="Full name"/></label>
      <label>Date of Birth<input required type="date" value={partnerBirthDate} onChange={e=>setPartnerBirthDate(e.target.value)} max={new Date().toISOString().slice(0,10)}/></label>
      <label>Place of Birth<input required value={partnerBirthPlace} onChange={e=>setPartnerBirthPlace(e.target.value)} placeholder="City, State, Country"/></label>
      <label>Time of Birth<input required type="time" value={partnerBirthTime} onChange={e=>setPartnerBirthTime(e.target.value)}/></label>
    </>}
    <label>{isHumanChat?"Message for Expert":"What would you like to know? (optional)"}<textarea rows="4" value={message} onChange={e=>setMessage(e.target.value)} placeholder="Write your question or any additional details"/></label>
    <button className="primary-btn full-btn" disabled={busy||!expert}>{busy?(isHumanChat?"Submitting...":"Preparing your report..."):(isHumanChat?"Chat Request":"Chat Request")}</button>
    {notice&&<div className="notice-inline">{notice}{/wallet|balance|fund|₹/i.test(notice)&&<Link className="add-funds-inline" to="/wallet">Add Amount →</Link>}</div>}
    {report&&<div className="ai-report-result"><h3>Your {serviceName} Report</h3><p>{report}</p></div>}
    <p className="form-footnote">Go to AstroFriend Consultation for astrology guidance. Chat charges begin only after the expert accepts and the chat starts.</p>
  </form></section>;
}
function LoginPage({user}) {
  const navigate=useNavigate(); const [params]=useSearchParams(); const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [notice,setNotice]=useState("");const [busy,setBusy]=useState(false);
  if(user)return <Navigate to="/" replace/>;
  const submit=async e=>{e.preventDefault();setBusy(true);setNotice("");try{const {data,error}=await supabase.auth.signInWithPassword({email:email.trim(),password});if(error)throw error;if(!data.user?.email_confirmed_at){await supabase.auth.signOut();throw new Error("Email verify nahi hua hai. Pehle 6-digit OTP verify karein.");}navigate(params.get("next")||"/");}catch(err){setNotice(err.message||"Login nahi ho paya.");}finally{setBusy(false);}};
  const sendReset=async()=>{if(!email.trim()){setNotice("Pehle Email Address box mein apna registered email likhein.");return;}setBusy(true);setNotice("");try{const {error}=await supabase.auth.resetPasswordForEmail(email.trim(),{redirectTo:`${window.location.origin}/reset-password`});if(error)throw error;setNotice("Password reset link aapke email par bhej diya gaya hai. Inbox aur Spam folder check karein.");}catch(err){setNotice(err.message||"Reset link nahi bheja ja saka.");}finally{setBusy(false);}};
  return <section className="page-section auth-page"><div className="form-card"><SectionHeading title="Welcome Back" text="Login with your verified email address."/><form onSubmit={submit}><label>Email Address<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input required type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Your password"/></label><button className="primary-btn full-btn" disabled={busy}>{busy?"Please wait...":"Login"}</button></form><p className="form-footnote"><button type="button" className="text-link" onClick={sendReset} disabled={busy}>Forgot Password?</button></p>{notice&&<p className="notice-inline">{notice}</p>}<p className="form-footnote">New to AstroFriend? <Link className="text-link" to="/signup">Create an account</Link></p></div></section>;
}
function ResetPasswordPage(){
  const [password,setPassword]=useState("");const [confirm,setConfirm]=useState("");const [notice,setNotice]=useState("");const [busy,setBusy]=useState(false);const navigate=useNavigate();
  const submit=async e=>{e.preventDefault();setNotice("");if(password.length<6){setNotice("Password कम से कम 6 characters का होना चाहिए।");return;}if(password!==confirm){setNotice("Dono password ek jaise nahi hain.");return;}setBusy(true);try{const {error}=await supabase.auth.updateUser({password});if(error)throw error;setNotice("Password successfully update ho gaya. Ab login karein.");setTimeout(()=>navigate("/login"),1200);}catch(err){setNotice(err.message||"Password update nahi ho paya. Reset email link dobara mangayein.");}finally{setBusy(false);}};
  return <section className="page-section auth-page"><div className="form-card"><SectionHeading title="Create New Password" text="Apne AstroFriend account ke liye naya password set karein."/><form onSubmit={submit}><label>New Password<input required minLength="6" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters"/></label><label>Confirm New Password<input required type="password" value={confirm} onChange={e=>setConfirm(e.target.value)} placeholder="Enter password again"/></label><button className="primary-btn full-btn" disabled={busy}>{busy?"Please wait...":"Update Password"}</button></form>{notice&&<p className="notice-inline">{notice}</p>}</div></section>;
}
function SignupPage() {
  const navigate=useNavigate();const [name,setName]=useState("");const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [confirm,setConfirm]=useState("");const [notice,setNotice]=useState("");const [busy,setBusy]=useState(false);
  const submit=async e=>{e.preventDefault();setNotice("");if(password.length<6)return setNotice("Password कम से कम 6 characters का होना चाहिए।");if(password!==confirm)return setNotice("दोनों password एक जैसे नहीं हैं।");setBusy(true);try{const {data,error}=await supabase.auth.signUp({email:email.trim(),password,options:{data:{full_name:name.trim()}}});if(error)throw error;if(data.session){await supabase.auth.signOut();throw new Error("Supabase में email confirmation बंद है। OTP के बिना account access रोक दिया गया है। Supabase Dashboard → Authentication → Providers → Email में Confirm email चालू करें, फिर दोबारा प्रयास करें।");}sessionStorage.setItem("astrofriend_pending_email",email.trim());navigate("/verify-email");}catch(err){setNotice(err.message||"Signup nahi ho paya.");}finally{setBusy(false);}};
  return <section className="page-section auth-page"><div className="form-card"><SectionHeading title="Create Account" text="Create your AstroFriend account. Email verification is required."/><form onSubmit={submit}><label>Full Name<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Your full name"/></label><label>Email Address<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input required minLength="6" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters"/></label><label>Confirm Password<input required type="password" value={confirm} onChange={e=>setConfirm(e.target.value)} placeholder="Enter password again"/></label><button className="primary-btn full-btn" disabled={busy}>{busy?"Creating account...":"Create Account"}</button></form>{notice&&<p className="notice-inline">{notice}</p>}<p className="form-footnote">Already registered? <Link className="text-link" to="/login">Login</Link></p></div></section>;
}
function VerifyPage() {
  const navigate=useNavigate();const [params]=useSearchParams();const [email,setEmail]=useState(sessionStorage.getItem("astrofriend_pending_email")||"");const [otp,setOtp]=useState("");const [notice,setNotice]=useState("");const [busy,setBusy]=useState(false);
  const submit=async e=>{e.preventDefault();if(!/^\d{6}$/.test(otp))return setNotice("कृपया 6 अंकों का OTP दर्ज करें।");setBusy(true);setNotice("");try{const {data,error}=await supabase.auth.verifyOtp({email:email.trim(),token:otp,type:"signup"});if(error)throw error;if(!data.user?.email_confirmed_at)throw new Error("Email verification confirm nahi hua. OTP dobara check karein.");sessionStorage.removeItem("astrofriend_pending_email");navigate(params.get("next")||"/");}catch(err){setNotice(err.message||"OTP verify nahi hua.");}finally{setBusy(false);}};
  return <section className="page-section auth-page"><div className="form-card"><SectionHeading title="Verify Your Email" text="Enter the 6-digit code sent to your email address."/><form onSubmit={submit}><label>Email Address<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>6-Digit OTP<input required inputMode="numeric" autoComplete="one-time-code" maxLength="6" value={otp} onChange={e=>setOtp(e.target.value.replace(/\D/g,"").slice(0,6))} placeholder="123456"/></label><button className="primary-btn full-btn" disabled={busy}>{busy?"Verifying...":"Verify Email"}</button></form>{notice&&<p className="notice-inline">{notice}</p>}<p className="form-footnote"><Link className="text-link" to="/signup">Back to signup</Link></p></div></section>;
}
function Protected({user,children}) { return user?children:<Navigate to="/login" replace/>; }

function AccountPage({user,onLogout}) {
  return <section className="page-section narrow-page"><SectionHeading title="My Account" text="Your AstroFriend customer account."/><div className="info-card"><div className="account-avatar">{(user.user_metadata?.full_name||user.email||"A").charAt(0).toUpperCase()}</div><h2>{user.user_metadata?.full_name||"AstroFriend Customer"}</h2><p>{user.email}</p><span className="verified-pill">✓ Email verified</span><div className="account-links"><Link className="secondary-btn" to="/">Meet Our Experts</Link><Link className="secondary-btn" to="/wallet">My Wallet</Link><Link className="secondary-btn" to="/inbox">Chat Inbox</Link><Link className="secondary-btn" to="/help-us">Help Us</Link><button type="button" className="secondary-btn" onClick={onLogout}>Logout</button></div></div></section>;
}
function WalletPage({user}) {
  const [wallet,setWallet]=useState(null),[transactions,setTransactions]=useState([]),[loading,setLoading]=useState(true),[amount,setAmount]=useState(""),[coupon,setCoupon]=useState(""),[couponBusy,setCouponBusy]=useState(false),[notice,setNotice]=useState("");
  const load=async()=>{setLoading(true);const [w,t]=await Promise.all([supabase.from("af_wallets").select("balance").eq("user_id",user.id).maybeSingle(),supabase.from("af_wallet_transactions").select("id,amount,kind,description,created_at").eq("user_id",user.id).order("created_at",{ascending:false}).limit(50)]);if(w.error)setNotice(w.error.message);setWallet(w.data||{balance:0});setTransactions(t.data||[]);setLoading(false);};
  useEffect(()=>{load();},[user.id]);
  const requestTopup=()=>{const n=Number(amount);if(!Number.isInteger(n)||n<20||n>100000){setNotice("Amount ₹20 से ₹1,00,000 के बीच होना चाहिए।");return;}setNotice("Online payment अभी activate नहीं है। Razorpay account और secure payment verification setup होने के बाद Add Money चालू होगा।");};
  const redeemCoupon=async()=>{if(!coupon.trim())return;setCouponBusy(true);setNotice("");const {data,error}=await supabase.rpc("af_redeem_coupon",{p_code:coupon.trim().toUpperCase()});if(error)setNotice(error.message);else{setNotice(`Coupon सफल! ₹${Number(data?.credited||0).toFixed(2)} आपके Wallet में जोड़ दिए गए।`);setCoupon("");await load();}setCouponBusy(false);};
  return <section className="page-section narrow-page"><SectionHeading title="My Wallet" text="Manage your consultation balance and transaction history."/>
    <div className="wallet-balance"><span>AVAILABLE BALANCE</span><strong>₹{Number(wallet?.balance||0).toFixed(2)}</strong><small>AstroFriend Wallet</small></div>
    <div className="form-card wallet-form"><h2>Redeem Coupon Code</h2><p className="muted-note">अगर आपके पास AstroFriend Coupon Code है, तो यहाँ डालकर Wallet में पैसे पाएँ।</p><label>Coupon Code<input value={coupon} onChange={e=>setCoupon(e.target.value.toUpperCase())} placeholder="Enter coupon code" maxLength={40}/></label><button className="primary-btn full-btn" onClick={redeemCoupon} disabled={couponBusy||!coupon.trim()}>{couponBusy?"Checking...":"Apply Coupon"}</button></div>
    <div className="form-card wallet-form"><h2>Add Money</h2><p className="muted-note">Minimum ₹20 · Maximum ₹1,00,000</p><label>Amount (₹)<input type="number" min="20" max="100000" step="1" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="Enter amount"/></label><button className="primary-btn full-btn" onClick={requestTopup}>Add Money</button><p className="form-footnote">Payments are temporarily unavailable. Your wallet cannot be credited manually from this screen.</p></div>
    <div className="transaction-panel"><h2>Transaction History</h2>{loading?<p>Loading...</p>:transactions.length===0?<p className="muted-note">No transactions yet.</p>:<div className="transaction-list">{transactions.map(t=><div className="transaction-row" key={t.id}><div><strong>{t.description||t.kind}</strong><small>{new Date(t.created_at).toLocaleString("en-IN")}</small></div><b className={Number(t.amount)>=0?"credit":"debit"}>{Number(t.amount)>=0?"+":"−"}₹{Math.abs(Number(t.amount)).toFixed(2)}</b></div>)}</div>}</div>{notice&&<p className="notice-inline">{notice}</p>}
  </section>;
}
function ChatPage({user}) {
  const [expertName,setExpertName]=useState(experts[0]?.name||""),[rate,setRate]=useState(5),[session,setSession]=useState(null),[messages,setMessages]=useState([]),[message,setMessage]=useState(""),[balance,setBalance]=useState(0),[notice,setNotice]=useState(""),[busy,setBusy]=useState(false),[seconds,setSeconds]=useState(0);
  const refresh=async()=>{const {data}=await supabase.from("af_wallets").select("balance").eq("user_id",user.id).maybeSingle();setBalance(Number(data?.balance||0));const {data:s}=await supabase.from("af_chat_sessions").select("*").eq("customer_id",user.id).in("status",["pending","active"]).order("created_at",{ascending:false}).limit(1).maybeSingle();if(s){setSession(s);const {data:m}=await supabase.from("af_chat_messages").select("*").eq("session_id",s.id).order("created_at");setMessages(m||[]);}else{setSession(null);setMessages([]);}};
  useEffect(()=>{refresh();const id=setInterval(refresh,5000);return()=>clearInterval(id);},[user.id]);
  useEffect(()=>{if(!session||session.status!=="active")return;const update=()=>setSeconds(Math.max(0,Math.floor((Date.now()-new Date(session.started_at).getTime())/1000)));update();const id=setInterval(update,1000);return()=>clearInterval(id);},[session?.id,session?.status,session?.started_at]);
  useEffect(()=>{if(!session||session.status!=="active")return;const id=setInterval(async()=>{const {data,error}=await supabase.rpc("af_charge_chat_minute",{p_session_id:session.id});if(error)setNotice(error.message);else if(data?.ended){setNotice("Wallet balance कम होने के कारण chat समाप्त हो गई।");refresh();}else if(data?.charged){setBalance(data.balance);}},5000);return()=>clearInterval(id);},[session?.id,session?.status]);
  const start=async()=>{const chosen=experts.find(e=>e.name===expertName);const perMinute=chosen?.level==="Senior"?5:4;if(balance<perMinute){setNotice(`Chat request ke liye wallet mein kam se kam ₹${perMinute} hona zaroori hai. Coupon redeem karein ya wallet top up karein.`);return;}setBusy(true);setNotice("");const {data,error}=await supabase.rpc("af_create_chat_request",{p_expert_name:expertName,p_rate_per_minute:perMinute});if(error)setNotice(error.message);else{setRate(perMinute);setNotice("Chat request भेज दी गई है। Expert के accept करने का इंतज़ार करें।");await refresh();}setBusy(false);};
  const send=async e=>{e.preventDefault();if(!message.trim()||!session)return;const text=message.trim();setMessage("");const {error}=await supabase.from("af_chat_messages").insert({session_id:session.id,sender:"customer",message:text});if(error)setNotice(error.message);else refresh();};
  const end=async()=>{if(!session)return;const {error}=await supabase.rpc("af_end_chat",{p_session_id:session.id});if(error)setNotice(error.message);await refresh();};
  return <section className="page-section narrow-page"><SectionHeading title="Talk to an Expert" text="Chat with an astrology expert. Charges are deducted from your wallet by the minute."/>
    {!session?<div className="form-card"><label>Select Expert<select value={expertName} onChange={e=>setExpertName(e.target.value)}>{experts.map(e=><option key={e.name}>{e.name}</option>)}</select></label><div className="price-preview"><span>Chat rate</span><strong>₹{experts.find(e=>e.name===expertName)?.level==="Senior"?5:4}/minute</strong></div><p className="muted-note">Current rate is based on your existing 5-minute chat prices. Senior: ₹5/min · Other: ₹4/min.</p><p className="muted-note">Wallet balance: ₹{balance.toFixed(2)}</p><button className="primary-btn full-btn" disabled={busy} onClick={start}>{busy?"Please wait...":"Request Chat"}</button></div>
    :<div className="chat-panel"><div className="chat-session-head"><div><strong>{session.expert_name}</strong><small>{session.status==="pending"?"Waiting for expert to accept":`₹${session.rate_per_minute}/minute · ${session.status}`}</small></div><div className="chat-clock">{String(Math.floor(seconds/60)).padStart(2,"0")}:{String(seconds%60).padStart(2,"0")}</div></div><div className="chat-messages">{messages.map(m=><div key={m.id} className={`chat-bubble ${m.sender==="customer"?"mine":"theirs"}`}><small>{m.sender==="customer"?"You":"Expert"}</small><p>{m.message}</p></div>)}</div>{session.status==="active"&&<form className="chat-compose" onSubmit={send}><input value={message} onChange={e=>setMessage(e.target.value)} placeholder="Type your message..." maxLength={2000}/><button className="primary-btn">Send</button></form>}<div className="chat-actions"><span>Wallet: ₹{balance.toFixed(2)}</span><button className="secondary-btn" onClick={end}>End Chat</button></div></div>}
    {notice&&<p className="notice-inline">{notice}</p>}
  </section>;
}
function InboxPage({user}) {
  const [sessions,setSessions]=useState([]),[notice,setNotice]=useState(""),[loading,setLoading]=useState(true);
  const load=async()=>{
    const {data,error}=await supabase.from("af_chat_sessions").select("*").eq("customer_id",user.id).order("created_at",{ascending:false});
    if(error)setNotice(error.message);else setSessions(data||[]);
    setLoading(false);
  };
  useEffect(()=>{load();const id=setInterval(load,5000);return()=>clearInterval(id);},[user.id]);
  return <section className="page-section"><SectionHeading title="My Chat Inbox" text="Your expert requests and conversations."/>
    <div className="inbox-list-page">
      {loading?<p className="muted-note">Loading your conversations...</p>:sessions.length===0?<div className="form-card"><p className="muted-note">Abhi koi chat request nahi hai. Home page se expert select karein.</p><Link className="primary-btn" to="/">Meet Our Experts</Link></div>:sessions.map(s=><Link key={s.id} className="inbox-item inbox-item-link" to={`/chat/${s.id}`}><strong>{s.expert_name}</strong><span>{s.status==="pending"?"Waiting for expert":s.status==="active"?"Live chat":"Completed"}</span><small>{new Date(s.created_at).toLocaleString("en-IN")}</small><small>₹{s.rate_per_minute}/minute</small><b>Open Chat →</b></Link>)}
    </div>{notice&&<p className="notice-inline">{notice}</p>}
  </section>;
}
function ChatConversationPage({user}) {
  const {sessionId}=useParams();
  const navigate=useNavigate();
  const [session,setSession]=useState(null),[messages,setMessages]=useState([]),[notice,setNotice]=useState(""),[seconds,setSeconds]=useState(0),[sending,setSending]=useState(false),[showAttach,setShowAttach]=useState(false),[balance,setBalance]=useState(0),[chatText,setChatText]=useState("");
  const load=async()=>{
    const {data,error}=await supabase.from("af_chat_sessions").select("*").eq("id",sessionId).eq("customer_id",user.id).maybeSingle();
    if(error||!data){setNotice(error?.message||"Chat nahi mili.");return;}
    setSession(data);
    const [{data:rows,error:messageError},{data:wallet}] = await Promise.all([
      supabase.from("af_chat_messages").select("*").eq("session_id",sessionId).order("created_at"),
      supabase.from("af_wallets").select("balance").eq("user_id",user.id).maybeSingle()
    ]);
    if(!messageError)setMessages(rows||[]);
    setBalance(Number(wallet?.balance||0));
  };
  useEffect(()=>{load();const id=setInterval(load,2500);return()=>clearInterval(id);},[sessionId,user.id]);
  useEffect(()=>{if(!session||session.status!=="active"||!session.started_at)return;const tick=()=>setSeconds(Math.max(0,Math.floor((Date.now()-new Date(session.started_at).getTime())/1000)));tick();const id=setInterval(tick,1000);return()=>clearInterval(id);},[session?.id,session?.status,session?.started_at]);
  useEffect(()=>{if(!session||session.status!=="active")return;const id=setInterval(async()=>{const {data,error}=await supabase.rpc("af_charge_chat_minute",{p_session_id:session.id});if(error)setNotice(error.message);else if(data?.ended){setNotice("Wallet balance khatam hone par chat end ho gayi.");await load();}else if(data?.balance!==undefined)setBalance(Number(data.balance));},5000);return()=>clearInterval(id);},[session?.id,session?.status]);
  const send=async e=>{e.preventDefault();const text=chatText.trim();if(!text||!session||session.status!=="active")return;setSending(true);const {error}=await supabase.from("af_chat_messages").insert({session_id:session.id,sender:"customer",message:text});if(error)setNotice(error.message);else{setChatText("");await load();}setSending(false);};
  const upload=async e=>{const file=e.target.files?.[0];e.target.value="";if(!file||!session||session.status!=="active")return;if(file.size>25*1024*1024){setNotice("File 25 MB se chhoti honi chahiye.");return;}setSending(true);const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");const path=`${session.id}/${user.id}/${Date.now()}-${safe}`;const {error:upErr}=await supabase.storage.from("af-chat-attachments").upload(path,file,{contentType:file.type||"application/octet-stream",upsert:false});if(upErr)setNotice(`File upload nahi hui: ${upErr.message}. SQL migration run karna zaroori hai.`);else{const {error}=await supabase.from("af_chat_messages").insert({session_id:session.id,sender:"customer",message:`Attachment: ${file.name}`,attachment_path:path,attachment_name:file.name,attachment_mime:file.type});if(error)setNotice(error.message);else await load();}setSending(false);setShowAttach(false);};
  const openAttachment=async path=>{const {data,error}=await supabase.storage.from("af-chat-attachments").createSignedUrl(path,300);if(error)setNotice(error.message);else window.open(data.signedUrl,"_blank","noopener,noreferrer");};
  const endSelected=async()=>{if(!session||!["pending","active"].includes(session.status))return;const {error}=await supabase.rpc("af_end_chat",{p_session_id:session.id});if(error)setNotice(error.message);else setNotice("Chat end kar di gayi hai. Aap baad mein dobara chat shuru kar sakte hain.");await load();};
  const restart=async()=>{
    if(!session)return;
    setSending(true);setNotice("");
    const {data,error}=await supabase.rpc("af_create_chat_request",{p_expert_name:session.expert_name,p_rate_per_minute:session.rate_per_minute});
    if(error){setNotice(error.message||"Insufficient Wallet Balance");setSending(false);return;}
    navigate(`/chat/${data}`);
  };
  const secondsToCharge=session?.next_charge_at?Math.max(0,Math.ceil((new Date(session.next_charge_at).getTime()-Date.now())/1000)):60;
  const needsFunds=session?.status==="active"&&secondsToCharge<=10&&balance<Number(session.rate_per_minute);
  return <section className="page-section chat-full-page">
    <div className="chat-page-top"><Link className="secondary-btn" to="/inbox">← Back to Inbox</Link></div>
    <SectionHeading title={session?.expert_name||"Expert Chat"} text="Your private conversation with the selected expert."/>
    {!session?<p className="muted-note">Loading chat...</p>:<div className="chat-panel chat-full-panel">
      <div className="chat-session-head"><div><strong>{session.expert_name}</strong><small>{session.status==="pending"?"Request sent · Waiting for expert":`${session.status} · ₹${session.rate_per_minute}/minute`}</small></div>{session.status==="active"&&<div className="chat-clock">{String(Math.floor(seconds/60)).padStart(2,"0")}:{String(seconds%60).padStart(2,"0")}</div>}</div>
      {needsFunds&&<div className="chat-funds-warning"><span>10 seconds left · Wallet balance kam hai</span><Link to="/wallet">Add Funds +</Link></div>}
      <div className="chat-messages chat-full-messages">{messages.length===0?<p className="muted-note">{session.status==="pending"?"Your information has been sent. Chat will open when the expert accepts.":"No messages yet."}</p>:messages.map(m=><div key={m.id} className={`chat-bubble ${m.sender==="customer"?"mine":"theirs"}`}><small>{m.sender==="customer"?"You":"Expert"}</small><p>{m.attachment_path?<button className="attachment-link" type="button" onClick={()=>openAttachment(m.attachment_path)}> {m.attachment_name||m.message} · Open file</button>:m.message}</p><small>{new Date(m.created_at).toLocaleString("en-IN")}</small></div>)}</div>
      {session.status==="active"&&<form className="chat-compose chat-full-compose" onSubmit={send}>
        <div className="attach-wrap"><button type="button" className="attach-plus" aria-label="Attach file" onClick={()=>setShowAttach(v=>!v)}>+</button>{showAttach&&<div className="attach-menu"><label>Photo / Video<input type="file" accept="image/*,video/*" onChange={upload} hidden/></label><label>Document<input type="file" accept=".pdf,.doc,.docx,.txt,.xls,.xlsx" onChange={upload} hidden/></label></div>}</div>
        <input name="chatMessage" type="text" value={chatText} onChange={e=>setChatText(e.target.value)} placeholder="Type your message..." maxLength="2000" disabled={sending||session.status!=="active"}/>
        <button className="primary-btn" disabled={sending||!chatText.trim()}>Send</button>
      </form>}
      <div className="chat-actions"><span>{session.status==="active"?`Timer running · ₹${session.rate_per_minute}/minute · Wallet ₹${balance.toFixed(2)}`:session.status==="pending"?"Waiting for expert acceptance": "Chat completed"}</span>{["pending","active"].includes(session.status)&&<button className="secondary-btn" type="button" onClick={endSelected}>End Chat</button>}{session.status==="ended"&&<button className="primary-btn" type="button" disabled={sending} onClick={restart}>Start Chat Again · ₹{session.rate_per_minute}/min</button>}</div>
    </div>}{notice&&<div className="notice-inline">{notice}{/wallet|balance|fund|₹/i.test(notice)&&<Link className="add-funds-inline" to="/wallet">Add Amount →</Link>}</div>}
  </section>;
}

function AstroAIPage({user}) {
  const [question,setQuestion]=useState("");
  const [messages,setMessages]=useState([{role:"assistant",content:"Namaste! AstroFriend Consultation mein aapka swagat hai. Main Kundli, astrology, numerology, rashifal, grah-gochar aur traditional future guidance se jude sawalon mein madad kar sakta hoon. Aap apna sawal poochhein."}]);
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState("");
  const [balance,setBalance]=useState(0);
  const [sessionId,setSessionId]=useState(null);
  const [seconds,setSeconds]=useState(0);
  const [ended,setEnded]=useState(false);
  const loadBalance=async()=>{const {data,error}=await supabase.from("af_wallets").select("balance").eq("user_id",user.id).maybeSingle();if(!error)setBalance(Number(data?.balance||0));};
  useEffect(()=>{loadBalance();},[user.id]);
  useEffect(()=>{
    if(!sessionId||ended)return;
    const id=setInterval(async()=>{
      const {data,error}=await supabase.rpc("af_charge_ai_minute",{p_session_id:sessionId});
      if(error){setNotice(error.message);return;}
      if(data?.ended){setEnded(true);setNotice("Wallet balance khatam ho gaya. Consultation rok di gayi hai.");}
      if(data?.charged){setBalance(Number(data.balance));setSeconds(v=>v+60);}
      if(data?.balance!==undefined)setBalance(Number(data.balance));
    },5000);
    return()=>clearInterval(id);
  },[sessionId,ended]);
  const send=async e=>{
    e.preventDefault();
    const prompt=question.trim();if(!prompt||busy||ended)return;
    setBusy(true);setNotice("");
    try{
      let activeSession=sessionId;
      if(!activeSession){
        const {data,error}=await supabase.rpc("af_start_ai_consultation");
        if(error)throw new Error(error.message);
        activeSession=data?.session_id||data;
        if(!activeSession)throw new Error("Consultation session start nahi hua.");
        setSessionId(activeSession);setBalance(v=>Math.max(0,v-5));
      }
      const next=[...messages,{role:"user",content:prompt}];
      setMessages(next);setQuestion("");
      const {data:authData}=await supabase.auth.getSession();
      const response=await fetch("/api/astro-ai",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${authData?.session?.access_token||""}`},body:JSON.stringify({sessionId:activeSession,messages:next.slice(-12).map(m=>({role:m.role,content:m.content}))})});
      const contentType=response.headers.get("content-type")||"";
      if(!contentType.includes("application/json")){
        throw new Error("Consultation server abhi connect nahi hai. Cloudflare AI service abhi connect nahi hai. Thodi der baad dobara try karein.");
      }
      const data=await response.json();
      if(!response.ok)throw new Error(data.error||`AI service error (${response.status}). Dobara try karein.`);
      setMessages(v=>[...v,{role:"assistant",content:data.reply}]);
      await loadBalance();
    }catch(err){setNotice(err.message||"AI se response nahi mila.");}
    finally{setBusy(false);}
  };
  const endConsultation=async()=>{
    if(!sessionId)return;
    const {error}=await supabase.rpc("af_end_ai_consultation",{p_session_id:sessionId});
    if(error)setNotice(error.message);else{setEnded(true);setNotice("Consultation end kar di gayi.");}
  };
  return <section className="page-section narrow-page"><SectionHeading title="AstroFriend Consultation" text="Kundli, numerology, horoscope aur traditional astrology guidance."/>
    <div className="form-card ai-wallet-rate"><div className="price-preview"><span>Consultation charges</span><strong>₹5/minute</strong></div><p className="muted-note">Har minute ₹5 aapke AstroFriend Wallet se deduct honge. Shuru karne ke liye wallet mein kam se kam ₹5 hona zaroori hai.</p><p className="muted-note">Wallet balance: ₹{balance.toFixed(2)} {sessionId&&!ended?` · Consultation time: ${Math.floor(seconds/60)} min`:""}</p>{sessionId&&!ended&&<button className="secondary-btn" type="button" onClick={endConsultation}>End Consultation</button>}</div>
    <div className="ai-chat-panel"><div className="ai-chat-head"><span className="ai-orb">✦</span><div><strong>AstroFriend Consultation</strong><small>Automated Astrology Consultation · ₹5/minute</small></div><span className="ai-online">{ended?"Ended":"Online"}</span></div>
    <div className="ai-chat-messages">{messages.map((m,i)=><div key={i} className={`ai-message ${m.role==="user"?"user":"assistant"}`}><small>{m.role==="user"?"You":"AstroFriend Consultation"}</small><p>{m.content}</p></div>)}{busy&&<div className="ai-message assistant"><small>AstroFriend Consultation</small><p>Soch raha hoon...</p></div>}</div>
    <form className="ai-compose" onSubmit={send}><textarea value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Apna Kundli, rashifal ya numerology ka sawal likhein..." rows="2" maxLength="3000"/><button className="primary-btn" disabled={busy||ended||!question.trim()||(!sessionId&&balance<5)}>{busy?"Please wait...":sessionId?"Send · ₹5/min":"Start · ₹5/min"}</button></form>
    {notice&&<p className="notice-inline">{notice}</p>}
    <p className="form-footnote">Consultation shuru karte hi pehle minute ke ₹5 deduct honge. Active consultation mein har agle minute ₹5 deduct honge. AI guidance traditional astrology par aadharit hai; guaranteed prediction nahi hai.</p></div>
  </section>;
}

function HelpUsPage({user}) {
  const [messages,setMessages]=useState([]),[text,setText]=useState(""),[busy,setBusy]=useState(false),[notice,setNotice]=useState("");
  const load=async()=>{const {data,error}=await supabase.from("af_support_messages").select("id,message,sender,created_at").eq("customer_id",user.id).order("created_at");if(error)setNotice(error.message);else setMessages(data||[]);};
  useEffect(()=>{load();const id=setInterval(load,4000);return()=>clearInterval(id);},[user.id]);
  const send=async e=>{e.preventDefault();if(!text.trim())return;setBusy(true);setNotice("");const {error}=await supabase.from("af_support_messages").insert({customer_id:user.id,sender:"customer",message:text.trim()});if(error)setNotice(error.message);else{setText("");await load();}setBusy(false);};
  return <section className="page-section narrow-page"><SectionHeading title="Help Us" text="Tell us about your issue. Our support team will receive your message."/><div className="chat-panel support-panel"><div className="chat-messages support-messages">{messages.length?messages.map(m=><div key={m.id} className={`chat-bubble ${m.sender==="customer"?"mine":"theirs"}`}><small>{m.sender==="customer"?"You":"AstroFriend Support"}</small><p>{m.message}</p><small>{new Date(m.created_at).toLocaleString("en-IN")}</small></div>):<p className="muted-note">No support messages yet. Send us your question below.</p>}</div><form className="chat-compose" onSubmit={send}><input value={text} onChange={e=>setText(e.target.value)} placeholder="Describe your problem..." maxLength={2000}/><button className="primary-btn" disabled={busy||!text.trim()}>Send</button></form></div>{notice&&<p className="notice-inline">{notice}</p>}</section>;
}
function AdminSupportInbox(){
 const [rows,setRows]=useState([]),[notice,setNotice]=useState("");
 const load=async()=>{const {data,error}=await supabase.from("af_support_messages").select("id,customer_id,message,sender,created_at").order("created_at",{ascending:false}).limit(100);if(error)setNotice(error.message);else setRows(data||[]);};
 useEffect(()=>{load();const id=setInterval(load,5000);return()=>clearInterval(id);},[]);
 return <div className="form-card admin-support"><h2>Help Us – Support Inbox</h2><p className="muted-note">Customer support messages received.</p>{rows.length?rows.map(r=><div className="support-row" key={r.id}><strong>{r.sender==="customer"?"Customer":"Admin"} · {r.customer_id}</strong><p>{r.message}</p><small>{new Date(r.created_at).toLocaleString("en-IN")}</small></div>):<p className="muted-note">No support messages yet.</p>}{notice&&<p className="notice-inline">{notice}</p>}<button type="button" className="secondary-btn" onClick={load}>Refresh support inbox</button></div>;
}

function AdminPage({user}) {
  const adminEmail=import.meta.env.VITE_ADMIN_EMAIL;
  const [sessions,setSessions]=useState([]),[selected,setSelected]=useState(null),[messages,setMessages]=useState([]),[reply,setReply]=useState(""),[notice,setNotice]=useState(""),[filter,setFilter]=useState("pending"),[busy,setBusy]=useState(false),[couponCode,setCouponCode]=useState(""),[couponAmount,setCouponAmount]=useState(""),[couponUses,setCouponUses]=useState("1"),[couponExpiry,setCouponExpiry]=useState(""),[chatSeconds,setChatSeconds]=useState(0);
  const allowed=!!adminEmail&&user.email?.toLowerCase()===adminEmail.toLowerCase();
  const load=async()=>{
    if(!allowed)return;
    const {data,error}=await supabase.rpc("af_admin_list_chats");
    if(error){setNotice(error.message);return;}
    const rows=data||[];setSessions(rows);
    if(selected){
      const latest=rows.find(x=>x.id===selected.id);
      if(latest)setSelected(latest);
      const {data:m,error:me}=await supabase.from("af_chat_messages").select("*").eq("session_id",selected.id).order("created_at",{ascending:true});
      if(me)setNotice(me.message);else setMessages(m||[]);
    }
  };
  useEffect(()=>{if(allowed){load();const id=setInterval(load,3000);return()=>clearInterval(id);}},[allowed,selected?.id]);
  useEffect(()=>{if(!selected)return;const id=setInterval(async()=>{const {data,error}=await supabase.from("af_chat_messages").select("*").eq("session_id",selected.id).order("created_at",{ascending:true});if(!error)setMessages(data||[]);},2500);return()=>clearInterval(id);},[selected?.id]);
  useEffect(()=>{if(!selected||selected.status!=="active"||!selected.started_at)return;const tick=()=>setChatSeconds(Math.max(0,Math.floor((Date.now()-new Date(selected.started_at).getTime())/1000)));tick();const id=setInterval(tick,1000);return()=>clearInterval(id);},[selected?.id,selected?.status,selected?.started_at]);
  if(!allowed)return <section className="page-section narrow-page"><div className="info-card"><h2>Admin access restricted</h2><p>Admin login ke liye Netlify environment variable VITE_ADMIN_EMAIL mein apna login email set karein aur Supabase mein af_admins table mein isi account ko add karein.</p></div></section>;
  const choose=async s=>{setSelected(s);setMessages([]);const {data,error}=await supabase.from("af_chat_messages").select("*").eq("session_id",s.id).order("created_at",{ascending:true});if(error)setNotice(error.message);else setMessages(data||[]);};
  const accept=async s=>{setBusy(true);const {error}=await supabase.rpc("af_start_chat",{p_session_id:s.id});if(error)setNotice(error.message);else{setNotice("Chat accept ho gayi. Ab customer ko reply kar sakte hain.");await load();}setBusy(false);};
  const send=async e=>{e.preventDefault();if(!reply.trim()||!selected||selected.status!=="active")return;setBusy(true);const {error}=await supabase.from("af_chat_messages").insert({session_id:selected.id,sender:"admin",message:reply.trim()});if(error)setNotice(error.message);else{setReply("");const {data}=await supabase.from("af_chat_messages").select("*").eq("session_id",selected.id).order("created_at",{ascending:true});setMessages(data||[]);}setBusy(false);};
  const adminUpload=async e=>{const file=e.target.files?.[0];e.target.value="";if(!file||!selected||selected.status!=="active")return;if(file.size>25*1024*1024){setNotice("File 25 MB se chhoti honi chahiye.");return;}setBusy(true);const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");const path=`${selected.id}/${user.id}/${Date.now()}-${safe}`;const {error:upErr}=await supabase.storage.from("af-chat-attachments").upload(path,file,{contentType:file.type||"application/octet-stream"});if(upErr)setNotice(`File upload nahi hui: ${upErr.message}. SQL migration run karein.`);else{const {error}=await supabase.from("af_chat_messages").insert({session_id:selected.id,sender:"admin",message:`Attachment: ${file.name}`,attachment_path:path,attachment_name:file.name,attachment_mime:file.type});if(error)setNotice(error.message);else{const {data}=await supabase.from("af_chat_messages").select("*").eq("session_id",selected.id).order("created_at");setMessages(data||[]);}}setBusy(false);};
  const adminOpenAttachment=async path=>{const {data,error}=await supabase.storage.from("af-chat-attachments").createSignedUrl(path,300);if(error)setNotice(error.message);else window.open(data.signedUrl,"_blank","noopener,noreferrer");};
  const endSelected=async()=>{if(!selected||!['pending','active'].includes(selected.status))return;if(!window.confirm("Kya aap is customer ki chat end karna chahte hain?"))return;setBusy(true);const {error}=await supabase.rpc("af_end_chat",{p_session_id:selected.id});if(error)setNotice(error.message);else{setNotice("Chat end kar di gayi hai. Aage ka wallet charge ruk gaya hai.");await load();}setBusy(false);};
  const createCoupon=async e=>{e.preventDefault();setBusy(true);setNotice("");const {data,error}=await supabase.rpc("af_admin_create_coupon",{p_code:couponCode.trim().toUpperCase(),p_amount:Number(couponAmount),p_max_uses:Number(couponUses),p_expires_at:couponExpiry?new Date(couponExpiry+"T23:59:59").toISOString():null});if(error)setNotice(error.message);else{setNotice(`Coupon ${data?.code||couponCode.toUpperCase()} create ho gaya. Amount ₹${couponAmount}, total uses ${couponUses}.`);setCouponCode("");setCouponAmount("");setCouponUses("1");setCouponExpiry("");}setBusy(false);};
  const visible=sessions.filter(s=>filter==="all"?true:s.status===filter);
  const counts={pending:sessions.filter(s=>s.status==="pending").length,active:sessions.filter(s=>s.status==="active").length,ended:sessions.filter(s=>s.status==="ended").length};
  return <section className="page-section"><SectionHeading title="Admin Chat Panel" text="Ek hi admin login se sabhi experts ki customer chats manage karein."/><AdminSupportInbox/>
    <div className="form-card" style={{marginBottom:24}}><h2>Create Wallet Coupon</h2><p className="muted-note">Customers coupon redeem karke wallet balance pa sakte hain.</p><form className="chat-compose" onSubmit={createCoupon}><input required value={couponCode} onChange={e=>setCouponCode(e.target.value.toUpperCase().replace(/\s/g,""))} placeholder="Coupon code (e.g. WELCOME50)" maxLength={40}/><input required type="number" min="1" step="1" value={couponAmount} onChange={e=>setCouponAmount(e.target.value)} placeholder="Amount ₹"/><input required type="number" min="1" step="1" value={couponUses} onChange={e=>setCouponUses(e.target.value)} placeholder="Max uses"/><input type="date" value={couponExpiry} onChange={e=>setCouponExpiry(e.target.value)} aria-label="Expiry date"/><button className="primary-btn" disabled={busy||!couponCode.trim()||Number(couponAmount)<=0||Number(couponUses)<1}>Create Coupon</button></form></div>
    <div className="admin-chat-summary"><div><strong>{counts.pending}</strong><span>New requests</span></div><div><strong>{counts.active}</strong><span>Active chats</span></div><div><strong>{counts.ended}</strong><span>Ended chats</span></div></div>
    <div className="admin-chat-tabs">{[["pending","New Requests"],["active","Active Chats"],["ended","Chat History"],["all","All Chats"]].map(([v,label])=><button key={v} className={filter===v?"active":""} onClick={()=>setFilter(v)}>{label}</button>)}<button className="admin-refresh" onClick={load}>Refresh</button></div>
    <div className="admin-chat-layout"><div className="admin-session-list">{visible.length===0?<p className="muted-note">Is section mein abhi koi chat nahi hai.</p>:visible.map(s=><button key={s.id} className={`admin-session ${selected?.id===s.id?"selected":""}`} onClick={()=>choose(s)}><strong>{s.customer_name||s.customer_email||"Customer"}</strong><small>{s.customer_email||s.customer_id}</small><small>Expert: {s.expert_name}</small><small>{s.status} · ₹{s.rate_per_minute}/min</small><small>{new Date(s.created_at).toLocaleString("en-IN")}</small></button>)}</div>
      <div className="admin-chat-window">{selected?<><div className="chat-session-head"><div><strong>{selected.customer_name||selected.customer_email||"Customer"}</strong><small>{selected.customer_email||selected.customer_id} · Expert: {selected.expert_name}</small></div><span>{selected.status==="active"?`${String(Math.floor(chatSeconds/60)).padStart(2,"0")}:${String(chatSeconds%60).padStart(2,"0")}`:selected.status}</span></div><div className="admin-customer-details"><h3>Customer Request Details</h3><div className="admin-detail-grid"><div><small>Customer Name</small><strong>{selected.booking_customer_name||selected.customer_name||"—"}</strong></div><div><small>Service</small><strong>{selected.service_name||"—"}</strong></div><div><small>Date of Birth</small><strong>{selected.birth_date||"—"}</strong></div><div><small>Time of Birth</small><strong>{selected.birth_time||"—"}</strong></div><div className="wide"><small>Place of Birth</small><strong>{selected.birth_place||"—"}</strong></div><div className="wide"><small>Message for Expert</small><strong>{selected.booking_message||"No additional message"}</strong></div></div></div><div className="chat-messages">{messages.length===0?<p className="muted-note">Abhi koi message nahi hai.</p>:messages.map(m=><div key={m.id} className={`chat-bubble ${m.sender==="admin"?"mine":"theirs"}`}><small>{m.sender==="admin"?"Admin":"Customer"}</small><p>{m.attachment_path?<button className="attachment-link" type="button" onClick={()=>adminOpenAttachment(m.attachment_path)}>📎 {m.attachment_name||m.message} · Open file</button>:m.message}</p><small>{new Date(m.created_at).toLocaleString("en-IN")}</small></div>)}</div>{selected.status==="pending"&&<button className="primary-btn" disabled={busy} onClick={()=>accept(selected)}>Accept Chat</button>}{selected.status==="active"&&<form className="chat-compose" onSubmit={send}><input value={reply} onChange={e=>setReply(e.target.value)} placeholder="Customer ko reply likhein..."/><label className="file-attach attach-plus" title="Attach photo, video or document">+<input type="file" accept="image/*,video/*,.pdf,.doc,.docx,.txt,.xls,.xlsx" onChange={adminUpload} hidden/></label><button className="primary-btn" disabled={busy||!reply.trim()}>Send</button></form>}{["pending","active"].includes(selected.status)&&<div className="chat-actions"><span>{selected.status==="active"?`Active · ₹${selected.rate_per_minute}/minute`:"Customer is waiting for acceptance"}</span><button className="secondary-btn" type="button" disabled={busy} onClick={endSelected}>End Chat</button></div>}{selected.status==="ended"&&<p className="notice-inline">Yeh chat end ho chuki hai. History read-only hai.</p>}</>:<p className="muted-note">Customer ki request select karein. Nayi request yahan automatically refresh hogi.</p>}</div></div>{notice&&<p className="notice-inline">{notice}</p>}</section>;
}

function NotFound(){return <section className="page-section narrow-page"><div className="info-card"><h2>Page not found</h2><Link className="text-link" to="/">Return Home →</Link></div></section>;}
export default function App(){return <BrowserRouter><AppShell/></BrowserRouter>;}