# AstroFriend — Cloudflare Pages migration starter

This project is prepared for Cloudflare Pages with a Pages Function at `functions/api/astro-ai.js`.
The existing Netlify deployment is not changed by this package.

## Build settings
- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`
- Root directory: `/`

## Required Pages environment variables
Set these for both Production and Preview as appropriate:
- `VITE_SUPABASE_URL` — existing Supabase project URL
- `VITE_SUPABASE_ANON_KEY` — existing Supabase anon/public key

Do not add the Supabase service-role key to the frontend or this project.

## Required Pages Function binding
In Cloudflare Dashboard → Workers & Pages → AstroFriend Pages project → Settings → Functions → AI bindings:
- Variable name: `AI`

Optional variable:
- `ASTROFRIEND_AI_MODEL` = `@cf/meta/llama-3.1-8b-instruct`

The AI binding uses Cloudflare Workers AI. The free allocation is limited; requests can fail after the daily free allocation is exhausted. Cloudflare notes that local development can also use the account AI service and consume usage.

## Before first deploy
1. Create a Cloudflare Pages project connected to the Git repository (recommended).
2. Add the environment variables and AI binding above.
3. Deploy to a temporary `*.pages.dev` address.
4. Test signup/login, booking, wallet, customer chat, admin inbox, AI consultation, and fixed-price report flows with a test account.
5. Keep the Netlify site live until all tests pass. Do not delete Netlify or change DNS before explicit approval.

## Important billing notes
- The existing Supabase RPCs remain responsible for wallet debits.
- The AI chat endpoint checks that the signed-in customer owns an active AI session; it does not debit the wallet itself. The existing `af_charge_ai_minute` RPC timer remains the billing authority.
- Fixed-price report requests require a signed-in user; `af_save_paid_booking` remains responsible for the report charge after generation.
- The model is not a chart-calculation engine. It must not invent planetary positions or ascendants. Accurate kundli placements require a separate ephemeris/chart-calculation integration.
