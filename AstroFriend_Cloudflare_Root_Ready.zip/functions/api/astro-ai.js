const SYSTEM_PROMPT = `You are AstroFriend's automated astrology consultation service. Never claim to be a named human expert or say that a selected expert personally wrote this answer.
Only answer questions about Vedic astrology, kundli, birth charts, planets, houses, nakshatras, rashifal, transits, compatibility, numerology, and traditional spiritual/astrological future guidance.
If a request is unrelated to these topics, politely say you can only help with astrology, kundli, numerology, horoscope, and related future guidance.
Do not invent exact planetary placements, ascendant, houses, nakshatras, or numerical compatibility scores unless verified chart data/calculation is supplied. The supplied birth details alone are not a calculated chart.
Do not claim predictions are certain or scientifically proven. Explain readings are traditional interpretations, not guarantees.
Do not give medical diagnosis or treatment, legal advice, investment instructions, or guaranteed outcomes.
Respond in the language used by the user; if Hindi/Hinglish, use Hindi/Hinglish. Be respectful and clear.`;

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
});

async function authenticate(request, env) {
  const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!token || !env.VITE_SUPABASE_URL || !env.VITE_SUPABASE_ANON_KEY) {
    throw Object.assign(new Error("Please login again to continue."), { status: 401 });
  }
  const response = await fetch(`${env.VITE_SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: env.VITE_SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
  });
  if (!response.ok) throw Object.assign(new Error("Login session invalid. Please login again."), { status: 401 });
  return { token, user: await response.json() };
}

function validateMessages(messages) {
  if (!Array.isArray(messages) || !messages.length || messages.length > 12) return false;
  return messages.every((m) =>
    m && ["user", "assistant"].includes(m.role) &&
    typeof m.content === "string" && m.content.trim().length > 0 && m.content.length <= 3000
  );
}

export async function onRequestPost({ request, env }) {
  try {
    if (!env.AI) return json({ error: "AstroFriend AI binding is not configured yet." }, 503);
    const { token, user } = await authenticate(request, env);
    const body = await request.json();
    const isPaidChat = typeof body.sessionId === "string" && body.sessionId.length > 0;
    let messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
    if (!validateMessages(messages)) return json({ error: "Invalid consultation request." }, 400);

    if (isPaidChat) {
      // The database owns minute billing. The browser's timer calls the secure RPC;
      // this endpoint only verifies that this user still has an active session.
      const params = new URLSearchParams({ id: `eq.${body.sessionId}`, select: "id,status,user_id" });
      const sessionResponse = await fetch(`${env.VITE_SUPABASE_URL}/rest/v1/af_ai_sessions?${params}`, {
        headers: { apikey: env.VITE_SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
      });
      if (!sessionResponse.ok) return json({ error: "Consultation session verify nahi ho paya. Dobara login karein." }, 401);
      const sessions = await sessionResponse.json();
      const session = sessions?.[0];
      if (!session || session.user_id !== user.id || session.status !== "active") {
        return json({ error: "Paid AI consultation session active nahi hai. Consultation dobara shuru karein." }, 402);
      }
    } else {
      // Fixed-price report requests also require a signed-in user. The existing
      // af_save_paid_booking RPC remains responsible for the actual wallet debit.
      const { service, expertName, birthDetails } = body;
      if (typeof service !== "string" || !birthDetails || typeof birthDetails !== "object" ||
          !birthDetails.date || !birthDetails.place || !birthDetails.time) {
        return json({ error: "Report ke liye poori birth details zaroori hain." }, 400);
      }
      const suppliedQuestion = messages[messages.length - 1]?.content || "Please prepare the requested report.";
      const reportContext = {
        service,
        selectedExpert: typeof expertName === "string" ? expertName : "AstroFriend automated service",
        birthDetails,
      };
      messages = [{
        role: "user",
        content: `${suppliedQuestion}\n\nCustomer-provided report details (use only as supplied; do not infer exact chart placements):\n${JSON.stringify(reportContext)}`,
      }];
    }

    const result = await env.AI.run(env.ASTROFRIEND_AI_MODEL || "@cf/meta/llama-3.1-8b-instruct", {
      messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
      max_tokens: 1100,
      temperature: 0.4,
    });
    const reply = result?.choices?.[0]?.message?.content || result?.response;
    if (typeof reply !== "string" || !reply.trim()) throw new Error("AI se jawab generate nahi ho paya. Dobara try karein.");
    return json({ reply });
  } catch (error) {
    const status = Number.isInteger(error?.status) ? error.status : 500;
    return json({ error: error?.message || "Astrology service error." }, status);
  }
}
