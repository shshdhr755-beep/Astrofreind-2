ASTROFRIEND — CLOUDFLARE PAGES READY PROJECT

IMPORTANT: Cloudflare Pages must see package.json, index.html, src/ and functions/ DIRECTLY at the repository root. Do NOT upload this ZIP as a ZIP file into GitHub and expect Pages to extract it. Extract this ZIP first, then upload the CONTENTS of the extracted folder to the GitHub repository root.

CLOUDFLARE PAGES BUILD SETTINGS
- Framework preset: React (Vite) (or Vite)
- Production branch: main
- Root directory / Path: leave EMPTY (repository root)
- Build command: npm run build
- Build output directory: dist
- Environment variable NODE_VERSION: 22 (Production and Preview)

KEEP THESE EXISTING ENVIRONMENT VARIABLES (use your actual existing values):
- VITE_SUPABASE_URL = your Supabase Project URL
- VITE_SUPABASE_ANON_KEY = your Supabase anon/public key
- VITE_ADMIN_EMAIL = your existing admin email, if used in your Cloudflare environment

PAGES FUNCTION AI BINDING
Cloudflare Dashboard > Workers & Pages > your AstroFriend Pages project > Settings > Functions > AI bindings.
Add binding:
- Variable name: AI
- AI model variable (optional): ASTROFRIEND_AI_MODEL = @cf/meta/llama-3.1-8b-instruct

Do not put Supabase service_role key in Pages environment variables exposed to the browser. Never share secrets in screenshots.

UPLOAD USING GITHUB WEBSITE
1. Open your repository and choose branch main.
2. Remove the old AstroFriend_Cloudflare_Migration.zip file from the repository (only that ZIP; do not delete unrelated files).
3. Extract this ZIP on Windows.
4. Open the extracted folder. Select ALL its contents (package.json, index.html, src, functions, public, supabase, etc.) and upload them to the repository root using Add file > Upload files. Preserve folders.
5. Commit to main.
6. Cloudflare Pages should start a new deployment automatically.

If uploading all files through the browser is awkward, use GitHub Desktop or VS Code to commit/push the extracted folder contents. The repository root must contain package.json and index.html, and src/main.jsx must exist at src/main.jsx.

DO NOT change DNS or delete the Netlify deployment yet. Test Cloudflare's temporary pages.dev URL first: home page, signup/login, email verification, wallet, booking, expert chat, admin inbox, AI chat and paid report. Existing Supabase database/RPCs are retained; this package does not alter the production database.

AI NOTE
The AI endpoint is Cloudflare Pages Function /api/astro-ai. It uses the Cloudflare Workers AI binding named AI and validates the signed-in Supabase user. Workers AI has usage limits; do not promise unlimited free use. Accurate planetary chart placements still require a dedicated ephemeris/chart calculation engine; the language model must not invent placements.
